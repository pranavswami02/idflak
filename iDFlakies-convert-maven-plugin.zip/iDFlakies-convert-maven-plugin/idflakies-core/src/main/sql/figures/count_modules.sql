select count(*)
from subject;