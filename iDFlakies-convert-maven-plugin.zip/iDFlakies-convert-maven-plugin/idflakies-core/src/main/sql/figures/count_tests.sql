select count(*)
from original_order;